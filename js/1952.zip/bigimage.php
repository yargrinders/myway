<?php

/*
$I_PAGE_HITS = 1234;
$I_ALL_HITS = 234523;
$I_ALL_HOSTS = 293;
*/

$im = imagecreatefrompng("buttons/{$I_SKIN}.png");


$textcolor = imagecolorallocate($im, 255, 255, 255);


imagestring($im, 1, 33, 2, $I_PAGE_HITS, $textcolor);
imagestring($im, 1, 33, 13, $I_ALL_HITS, $textcolor);

imagestring($im, 1, 33, 22, $I_ALL_HOSTS, $textcolor);


header("Content-type: image/png");
imagepng($im);

?>