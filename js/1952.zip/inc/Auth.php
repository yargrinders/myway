<?php

require_once('inc/Session.class.php');

define('SESS_AUTH', 'sess_authed_user');

class Auth
{
	function present() 
	{
		return Session::is_set(SESS_AUTH);
	}
	
	function login($username, $password) 
	{
		global $conf_site_user, $conf_site_pass;
		if (($username == $conf_site_user) && ($password == $conf_site_pass))
		{
			Session::removeall();
			Session::set(SESS_AUTH, true);
			return true;
		}
		return false;
	}
	
	function logout() 
	{
		Session::destroy();
	}
}



?>