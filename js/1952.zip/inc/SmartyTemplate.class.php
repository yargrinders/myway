<?php

require_once "lib/Smarty/Smarty.class.php";

class SmartyTemplate extends Smarty
{
	function SmartyTemplate($template_dir, $compile_dir) 
	{
		$this->Smarty();
		$this->template_dir = $template_dir;
        $this->compile_dir  = $compile_dir;
	}

	function display($base_tpl, $content_tpl)
	{
		if ($content_tpl)
		{
			$this->assign('content_tpl', $content_tpl);
		}
		Smarty::display($base_tpl);
	}
}

?>