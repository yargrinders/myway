<?php

$OLT_ON_SENGIES = array(
	'yandex' => array('yandex.ru'),
	'google' => array('google.'),
	'rambler' => array('rambler.ru'),
	'mailru' => array('go.mail.ru'),
	'aport' => array('sm.aport.ru'),
	'webalta' => array('webalta.ru')
	);
require_once('inc/encoding.php');


//////////////////////////////////////////////////////////////////////////////////////////////////


function exist_and_notblank($array, $name)
{
	return (isset($array[$name]) && strlen($array[$name])>0);
}

function insert_se_query($hit_id, $se_id, $query)
{
	global $conf_db_pref;
	$query = addslashes($query);
	$sql = "INSERT INTO {$conf_db_pref}searches (hit_id, searcher, query) VALUES ($hit_id, $se_id, '$query')";
	return query_insert($sql);
}
//////////////////////////////////////////////////////////////////////////////////////////////////


//	-	-	-	-	-	-	-	-	-	-	-	-	-	YANDEX
function check_ref_yandex
($hit_id, $path, $query_vars)
{
	if ($path == '/yandsearch' || $path == '/yandpage')
	{
		if (exist_and_notblank($query_vars, 'text'))
		{
			insert_se_query($hit_id, SEID_YANDEX, $query_vars['text']);
		}
	}
}

//	-	-	-	-	-	-	-	-	-	-	-	-	-	GOOGLE
function check_ref_google
($hit_id, $path, $query_vars)
{
	if ($path == '/search')
	{
		if (exist_and_notblank($query_vars, 'q'))
		{
			$query = utf8_to_cp1251($query_vars['q']);
			insert_se_query($hit_id, SEID_GOOGLE, $query);
		}
	}
}

//	-	-	-	-	-	-	-	-	-	-	-	-	-	RAMBLER
function check_ref_rambler
($hit_id, $path, $query_vars)
{
	//TODO: fix rambler
	if (!exist_and_notblank($query_vars, 'words')) return;
	$words = $query_vars['words'];
	$top100 = false;
	if ($path == '/srch')
	{
		if (exist_and_notblank($query_vars, 'set'))
		{
			if ($query_vars['set'] == 'top100')
				$top100 = true;
		}
	}
	elseif ($path == '/cgi-bin/counter_search')
	{
		$top100 = true;
	}
	else return;
	/*
	if ($top100)//TODO: and oe != 1251
	{
		$words = convert_cyr_string($words, 'k', 'w');
	}
	*/
	
	insert_se_query($hit_id, SEID_RAMBLER, $words);
}

//	-	-	-	-	-	-	-	-	-	-	-	-	-	MAIL.RU
function check_ref_mailru
($hit_id, $path, $query_vars)
{
	if ($path == '/search')
	{
		if (exist_and_notblank($query_vars, 'q'))
		{
			insert_se_query($hit_id, SEID_MAILRU, $query_vars['q']);
		}
	}
}

//	-	-	-	-	-	-	-	-	-	-	-	-	-	APORT
function check_ref_aport
($hit_id, $path, $query_vars)
{
	if (exist_and_notblank($query_vars, 'r'))
	{
		insert_se_query($hit_id, SEID_APORT, $query_vars['r']);
	}
}

//	-	-	-	-	-	-	-	-	-	-	-	-	-	WEBALTA
function check_ref_webalta
($hit_id, $path, $query_vars)
{
	if ($path == '/search')
	{
		if (exist_and_notblank($query_vars, 'q'))
		{
			$query = utf8_to_cp1251($query_vars['q']);
			insert_se_query($hit_id, SEID_WEBALTA, $query);
		}
	}
}
//////////////////////////////////////////////////////////////////////////////////////////////////

function process_referrer($ref, $hit_id)
{
	global $OLT_ON_SENGIES;
	$url_parsed = parse_url($ref);
	$r_host = strtolower($url_parsed['host']);
	$r_path = strtolower($url_parsed['path']);
	parse_str($url_parsed['query'], $r_query);
	
	foreach ($OLT_ON_SENGIES as $engine => $accepted_hosts) 
	{
		foreach ($accepted_hosts as $host)
		{
			if (strpos($r_host, $host) !== false)
			{
				$checker = "check_ref_" . $engine;
				$checker($hit_id, $r_path, $r_query);
				return ;
			}
		}
	}	
}






?>