<?php /* Smarty version 2.6.14, created on 2007-04-10 11:55:58
         compiled from login.tpl */ ?>
<br><br><br>
<form action="index.php" method="POST" name="form1">
<input type="hidden" name="mode" value="auth">
<table>
<?php if (isset ( $this->_tpl_vars['errors'] )): ?>
<tr>
	<td colspan="2">
		<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "err_msg.tpl", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
	</td>
</tr>
<?php endif; ?>
<tr>
	<td>�����</td>
	<td><input type="text" name="login" value="<?php echo $this->_tpl_vars['login']; ?>
"></td>
</tr>
<tr>
	<td>������</td>
	<td><input type="password" name="pass"></td>
</tr>
<tr>
	<td>&nbsp;</td>
	<td><input type="submit" value="����"></td>
</tr>
</table>