<?php /* Smarty version 2.6.14, created on 2007-04-10 11:56:00
         compiled from common.tpl */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('function', 'html_options', 'common.tpl', 4, false),)), $this); ?>
<h2>����� ����������</h2>
<form method="GET">
<input type="hidden" name="mode" value="main">
<?php echo smarty_function_html_options(array('name' => 'day','options' => $this->_tpl_vars['dpick_day_vals'],'selected' => $this->_tpl_vars['dpick_day']), $this);?>

<?php echo smarty_function_html_options(array('name' => 'month','options' => $this->_tpl_vars['dpick_month_vals'],'selected' => $this->_tpl_vars['dpick_month']), $this);?>

<?php echo smarty_function_html_options(array('name' => 'year','options' => $this->_tpl_vars['dpick_year_vals'],'selected' => $this->_tpl_vars['dpick_year']), $this);?>

<input type="submit" value="��������">
</form>
<table width="250">
	<tr>
		<td>����������:</td>
		<td><?php echo $this->_tpl_vars['stats']['hits']; ?>
</td>
	<tr>
	<tr>
		<td>�����������:</td>
		<td><?php echo $this->_tpl_vars['stats']['visitors']; ?>
</td>
	<tr>
	<tr>
		<td>������:</td>
		<td><?php echo $this->_tpl_vars['stats']['hosts']; ?>
</td>
	<tr>
</table>