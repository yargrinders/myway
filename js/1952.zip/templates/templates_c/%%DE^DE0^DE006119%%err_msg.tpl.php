<?php /* Smarty version 2.6.14, created on 2007-04-10 12:26:45
         compiled from err_msg.tpl */ ?>
			<div class="warning-msg">
				<br><strong>������</strong><br><br>
				<?php $_from = $this->_tpl_vars['errors']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['str']):
?>
					- <?php echo $this->_tpl_vars['str']; ?>
<br>
				<?php endforeach; endif; unset($_from); ?>
				<br>
			</div>