<?php /* Smarty version 2.6.14, created on 2007-04-10 12:16:42
         compiled from searches.tpl */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('function', 'html_options', 'searches.tpl', 4, false),)), $this); ?>
<h2>��������� ����������</h2>
<form method="GET">
<input type="hidden" name="mode" value="searches">
<?php echo smarty_function_html_options(array('name' => 'day','options' => $this->_tpl_vars['dpick_day_vals'],'selected' => $this->_tpl_vars['dpick_day']), $this);?>

<?php echo smarty_function_html_options(array('name' => 'month','options' => $this->_tpl_vars['dpick_month_vals'],'selected' => $this->_tpl_vars['dpick_month']), $this);?>

<?php echo smarty_function_html_options(array('name' => 'year','options' => $this->_tpl_vars['dpick_year_vals'],'selected' => $this->_tpl_vars['dpick_year']), $this);?>

<input type="submit" value="��������">
</form>
<table>
	<tr class="head">
		<td>URL</td>
		<td>Hits</td>
		<td>Visitors</td>
		
		<td>Yandex</td>
		<td>Google</td>
		<td>Rambler</td>
		<td>Mail.ru</td>
		<td>Aport</td>
		<td>Webalta</td>
		<td>% ������ ��������</td>
	</tr>
<?php $_from = $this->_tpl_vars['stats']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['item']):
?>	
	<tr>
		<td><a href="<?php echo $this->_tpl_vars['item']['url']; ?>
" class="url"><?php echo $this->_tpl_vars['item']['url']; ?>
</a></td>
		<td><b><?php echo $this->_tpl_vars['item']['hits']; ?>
</b></td>
		<td><b><?php echo $this->_tpl_vars['item']['visitors']; ?>
</b></td>
		
		<td><a href="index.php?mode=queries&s=1&d=<?php echo $this->_tpl_vars['date']; ?>
&p=<?php echo $this->_tpl_vars['item']['page_id']; ?>
" class="detail"><?php echo $this->_tpl_vars['item']['searches']['yandex']; ?>
</a></td>
		<td><a href="index.php?mode=queries&s=2&d=<?php echo $this->_tpl_vars['date']; ?>
&p=<?php echo $this->_tpl_vars['item']['page_id']; ?>
" class="detail"><?php echo $this->_tpl_vars['item']['searches']['google']; ?>
</a></td>
		<td><a href="index.php?mode=queries&s=3&d=<?php echo $this->_tpl_vars['date']; ?>
&p=<?php echo $this->_tpl_vars['item']['page_id']; ?>
" class="detail"><?php echo $this->_tpl_vars['item']['searches']['rambler']; ?>
</a></td>
		<td><a href="index.php?mode=queries&s=4&d=<?php echo $this->_tpl_vars['date']; ?>
&p=<?php echo $this->_tpl_vars['item']['page_id']; ?>
" class="detail"><?php echo $this->_tpl_vars['item']['searches']['mailru']; ?>
</a></td>
		<td><a href="index.php?mode=queries&s=5&d=<?php echo $this->_tpl_vars['date']; ?>
&p=<?php echo $this->_tpl_vars['item']['page_id']; ?>
" class="detail"><?php echo $this->_tpl_vars['item']['searches']['aport']; ?>
</a></td>
		<td><a href="index.php?mode=queries&s=6&d=<?php echo $this->_tpl_vars['date']; ?>
&p=<?php echo $this->_tpl_vars['item']['page_id']; ?>
" class="detail"><?php echo $this->_tpl_vars['item']['searches']['webalta']; ?>
</a></td>
		<td><b><?php echo $this->_tpl_vars['item']['loads']; ?>
</b></td>
	</tr>
<?php endforeach; endif; unset($_from); ?>
</table>