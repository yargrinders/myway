<?php /* Smarty version 2.6.14, created on 2007-04-10 12:06:29
         compiled from getcode.tpl */ ?>
<script>
<?php echo '
function updCode(name)
{
	var code = document.getElementById(\'code2\').value;
	code = code.replace(/&skin=.*?&/, \'&skin=\' + name + \'&\');
	document.getElementById(\'code2\').value = code;
	return true;
}
'; ?>

</script>
<h3>��� ��������</h3>

<?php $_from = $this->_tpl_vars['buttons']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['name']):
?>
	<input type="radio" name="thecode" onclick="updCode('<?php echo $this->_tpl_vars['name']; ?>
')"<?php if ($this->_tpl_vars['name'] == $this->_tpl_vars['sel_button']): ?> checked<?php endif; ?>><img src="./buttons/<?php echo $this->_tpl_vars['name']; ?>
.png">
<?php endforeach; endif; unset($_from); ?>
<br><br>
<b>1x1</b><br>
<textarea rows="5" cols="70" onfocus="this.select()" readonly><?php echo $this->_tpl_vars['code1']; ?>
</textarea>
<br>
<br>
<b>88x31</b><br>
<textarea rows="5" cols="70" id="code2"  onfocus="this.select()" readonly><?php echo $this->_tpl_vars['code2']; ?>
</textarea>