<?php

function smarty_modifier_dateview($string, $default = '')
{
    return date("d.m.Y", $string);
}

/* vim: set expandtab: */

?>
