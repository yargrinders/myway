<?php

	require_once('config.php');

	//TODO: remove files - PEAR unused dbs, SMARTY unused plugins
	
	$CUR_DIR = dirname(__FILE__);
	
//--------------DATABASE ----------		
	if (!defined("PATH_SEPARATOR"))
		define("PATH_SEPARATOR", substr(php_uname(), 0, 3) == 'Win' ? ';' : ':');
	ini_set("include_path", "." . PATH_SEPARATOR . "$CUR_DIR/lib/PEAR"); 
	
	

	require_once('inc/Database.class.php');
	$db = new Database($conf_db_type, $conf_db_host
						, $conf_db_user, $conf_db_pass, $conf_db_name);
	
	if (!$db->connect())
		die('ERROR(db connect):' . $db->getMessage());//TODO: die - log_die
//-------------- 


if (isset($OLT_LOAD_SMARTY))
{
	include_once('inc/SmartyTemplate.class.php');
	$tpl = new SmartyTemplate("$CUR_DIR/templates", "$CUR_DIR/templates/templates_c"); 
}


define('SEID_YANDEX', 	1);
define('SEID_GOOGLE', 	2);
define('SEID_RAMBLER', 	3);
define('SEID_MAILRU', 	4);
define('SEID_APORT', 	5);
define('SEID_WEBALTA', 	6);//TODO: if you change this - update tempaltes!

$id_tosengine[SEID_YANDEX] ='yandex';
$id_tosengine[SEID_GOOGLE] ='google';
$id_tosengine[SEID_RAMBLER] ='rambler';
$id_tosengine[SEID_MAILRU] ='mailru';
$id_tosengine[SEID_APORT] ='aport';
$id_tosengine[SEID_WEBALTA] ='webalta';


$se_ru_names[SEID_YANDEX] ='������';
$se_ru_names[SEID_GOOGLE] ='Google';
$se_ru_names[SEID_RAMBLER] ='�������';
$se_ru_names[SEID_MAILRU] ='Mail.RU';
$se_ru_names[SEID_APORT] ='�����';
$se_ru_names[SEID_WEBALTA] ='Webalta';
?>